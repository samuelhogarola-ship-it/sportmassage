<?php
if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>
<section class="hero">
    <div class="hero-inner">
        <p class="eyebrow"><?php esc_html_e('Blog', 'sports-massage-blog'); ?></p>
        <h1 class="hero-title"><?php single_post_title(); ?></h1>
        <p class="hero-summary"><?php esc_html_e('Listado de artículos con el mismo lenguaje visual que la web actual.', 'sports-massage-blog'); ?></p>
    </div>
</section>

<main class="content-grid">
    <div class="content-main">
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <article <?php post_class('entry-card'); ?>>
                    <div class="post-meta"><?php echo esc_html(get_the_date()); ?></div>
                    <h2 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <div class="entry-summary"><?php the_excerpt(); ?></div>
                </article>
            <?php endwhile; ?>
            <div class="entry-card"><?php the_posts_pagination(); ?></div>
        <?php else : ?>
            <article class="entry-card">
                <h2 class="entry-title"><?php esc_html_e('Todavía no hay artículos', 'sports-massage-blog'); ?></h2>
                <p><?php esc_html_e('Publica tu primera entrada y aparecerá aquí.', 'sports-massage-blog'); ?></p>
            </article>
        <?php endif; ?>
    </div>
    <aside class="content-sidebar">
        <?php get_sidebar(); ?>
    </aside>
</main>
<?php
get_footer();
