<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<section class="section footer-cta">
    <div class="section-inner">
        <div class="section-heading">
            <p class="section-eyebrow"><?php esc_html_e('Contact', 'sports-massage-blog'); ?></p>
            <h2 class="section-title"><?php esc_html_e('Ready to launch your blog?', 'sports-massage-blog'); ?></h2>
            <p class="section-copy"><?php esc_html_e('This theme keeps the same visual direction as the main website and gives you a strong base for a professional WordPress blog.', 'sports-massage-blog'); ?></p>
        </div>
        <a class="button-primary" href="<?php echo esc_url(home_url('/contacto')); ?>"><?php esc_html_e('Go to contact', 'sports-massage-blog'); ?></a>
    </div>
</section>

<footer class="site-footer">
    <div class="site-footer-inner">
        <div class="footer-title"><?php bloginfo('name'); ?></div>
        <div class="footer-copy">© <?php echo esc_html(date_i18n('Y')); ?> · <?php bloginfo('name'); ?></div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
